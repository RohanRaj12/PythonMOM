from flask import Flask, render_template, jsonify, request
import time
import azure.cognitiveservices.speech as speechsdk
import threading
import requests
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from datetime import datetime

# Azure Speech and OpenAI configuration
speech_key = "GGghrgVaEhCjUtxWSiIOrZB5RNmqauJPgrG062EnXRRzZoqlLbRrJQQJ99BGACYeBjFXJ3w3AAAYACOGy3f0"
service_region = "Eastus"
GPT4V_KEY = "9HAgJQqYC312LHNE5SJYVTmLSBjGOq1Bz5xdS5yXaAYMxuo0dX9IJQQJ99BGACYeBjFXJ3w3AAABACOG4jtK"
GPT4V_ENDPOINT = "https://testspchsrvc1.openai.azure.com/"
headers = {
    "Content-Type": "application/json",
    "api-key": GPT4V_KEY,
}

ENDPOINT_SILENCE_TIMEOUT_MS = 5000  # 5 seconds

app = Flask(__name__)
transcription_result = {"text": "", "response": ""}
recognizer = None
recognition_thread = None
done = False

def setup_speech_recognition():
    speech_config = speechsdk.SpeechConfig(subscription=speech_key, region=service_region)
    speech_config.set_property(speechsdk.PropertyId.SpeechServiceConnection_EndSilenceTimeoutMs, str(ENDPOINT_SILENCE_TIMEOUT_MS))
    audio_config = speechsdk.audio.AudioConfig(use_default_microphone=True)
    recognizer = speechsdk.SpeechRecognizer(speech_config=speech_config, audio_config=audio_config)
    return recognizer

def continuous_transcription():
    global transcription_result, done, recognizer
    recognizer = setup_speech_recognition()
    accumulated_text = []

    def handle_continuous_result(evt):
        result = evt.result
        if result.reason == speechsdk.ResultReason.RecognizedSpeech:
            accumulated_text.append(result.text)

    def handle_session_stopped(evt):
        global done
        complete_transcription = " ".join(accumulated_text)
        transcription_result["text"] = complete_transcription
        response = analyze_text_with_openai(complete_transcription)
        transcription_result["response"] = response
        done = True

    def handle_no_speech(evt):
        recognizer.stop_continuous_recognition_async()

    recognizer.recognized.connect(handle_continuous_result)
    recognizer.session_stopped.connect(handle_session_stopped)
    recognizer.speech_end_detected.connect(handle_no_speech)

    recognizer.start_continuous_recognition_async().get()
    while not done:
        time.sleep(1)

def analyze_text_with_openai(text):
    prompt = (
        "You are a highly intelligent assistant. Here is the transcription of a meeting:\n\n"
        f"{text}\n\n"
        "Please generate a summary and action items for this meeting transcription."
    )
    payload = {
        "messages": [
            {"role": "system", "content": "You are a highly intelligent assistant, especially related generating a summary and action items for a meeting transcription."},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "top_p": 0.95,
        "max_tokens": 800
    }

    try:
        response = requests.post(GPT4V_ENDPOINT, headers=headers, json=payload)
        response.raise_for_status()
        response_data = response.json()
        return response_data['choices'][0]['message']['content'].strip()
    except Exception as e:
        return str(e)

@app.route('/')
def index():
    return render_template('index2.html')

@app.route('/start_transcription', methods=['POST'])
def start_transcription():
    global recognition_thread, done
    done = False
    recognition_thread = threading.Thread(target=continuous_transcription)
    recognition_thread.start()
    return jsonify({"status": "started"})

@app.route('/stop_transcription', methods=['POST'])
def stop_transcription():
    global recognizer
    if recognizer:
        recognizer.stop_continuous_recognition_async()
    return jsonify({"status": "stopped"})

@app.route('/get_transcription', methods=['GET'])
def get_transcription():
    return jsonify(transcription_result)

@app.route('/get_formatted_email', methods=['GET'])
def get_formatted_email():
    now = datetime.now()
    formatted_body = f"Date: {now.strftime('%d %B %Y')}\nTime: {now.strftime('%I:%M %p')}\n\n{transcription_result['response']}"
    return jsonify({"formatted_email": formatted_body})

if __name__ == "__main__":
    app.run(debug=True, port=5001)
